#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "=== OPHOST Docker VPS Deploy Bot installer ==="
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker CLI not found. Install Docker Engine first: https://docs.docker.com/engine/install/"
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "Docker daemon is not reachable. Start Docker Engine and rerun."
  exit 1
fi
if [ ! -f .env ]; then
  read -r -s -p "Discord bot token: " BOT_TOKEN; echo
  while true; do
    read -r -p "Admin Discord user ID: " ADMIN_ID
    if [[ "$ADMIN_ID" =~ ^[0-9]{15,22}$ ]]; then break; fi
    echo "Enter a numeric Discord user ID."
  done
  read -r -p "Discord server ID for fast slash sync (0 = global): " GUILD_ID
  GUILD_ID="${GUILD_ID:-0}"
  read -r -p "Default member RAM limit [2g]: " MEMBER_RAM
  MEMBER_RAM="${MEMBER_RAM:-2g}"
  read -r -p "Default member CPU limit [1.0]: " MEMBER_CPUS
  MEMBER_CPUS="${MEMBER_CPUS:-1.0}"
  umask 077
  cat > .env <<EOF
BOT_TOKEN=${BOT_TOKEN}
ADMIN_IDS=${ADMIN_ID}
GUILD_ID=${GUILD_ID}
PREFIX=!
VPS_IMAGE=ophost-vps:latest
MEMBER_RAM=${MEMBER_RAM}
MEMBER_CPUS=${MEMBER_CPUS}
MEMBER_DISK_NOTE=10 GB (configure a host volume quota separately)
MAX_VPS_PER_MEMBER=1
EOF
  chmod 600 .env
else
  echo ".env already exists; keeping existing settings."
fi
mkdir -p data
echo "Building VPS image..."
docker build -t ophost-vps:latest .
echo "Installing bot dependencies in a local Python venv..."
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo
echo "Install complete."
echo "Run bot: source .venv/bin/activate && python bot.py"
echo "Or run containerized bot: docker compose up -d --build"
echo "WARNING: bot requires Docker socket access. Only use on a VPS you control."
