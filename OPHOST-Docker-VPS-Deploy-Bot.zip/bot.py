import os, asyncio, secrets, string, subprocess, shlex
from pathlib import Path
import discord
from discord.ext import commands
from discord import app_commands
import docker
from docker.errors import NotFound, APIError

TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
GUILD_ID = int(os.getenv("GUILD_ID", "0") or 0)
PREFIX = os.getenv("PREFIX", "!")
IMAGE = os.getenv("VPS_IMAGE", "ophost-vps:latest")
MEMBER_RAM = os.getenv("MEMBER_RAM", "2g")
MEMBER_CPUS = float(os.getenv("MEMBER_CPUS", "1.0"))
MEMBER_DISK_NOTE = os.getenv("MEMBER_DISK_NOTE", "10 GB (configure a host volume quota separately)")
MAX_VPS_PER_MEMBER = int(os.getenv("MAX_VPS_PER_MEMBER", "1"))

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents)
docker_client = docker.from_env()
state_dir = Path("data")
state_dir.mkdir(exist_ok=True)
# Mapping is persisted locally: Discord user ID -> container name.
mapping_file = state_dir / "members.txt"

def is_admin_id(uid: int) -> bool:
    return uid in ADMIN_IDS

def load_mapping():
    data = {}
    if mapping_file.exists():
        for line in mapping_file.read_text().splitlines():
            parts = line.split(" ", 1)
            if len(parts) == 2 and parts[0].isdigit():
                data[int(parts[0])] = parts[1]
    return data

def save_mapping(data):
    mapping_file.write_text("".join(f"{uid} {name}\n" for uid, name in data.items()))

def member_container(uid: int):
    mapping = load_mapping()
    name = mapping.get(uid)
    if not name:
        return None
    try:
        return docker_client.containers.get(name)
    except NotFound:
        return None

def safe_name(uid: int):
    return f"ophost-user-{uid}"

def make_password(n=20):
    chars = string.ascii_letters + string.digits + "!@#$%_-"
    return "".join(secrets.choice(chars) for _ in range(n))

async def reply(ctx_or_interaction, text, ephemeral=False):
    if isinstance(ctx_or_interaction, discord.Interaction):
        if ctx_or_interaction.response.is_done():
            await ctx_or_interaction.followup.send(text, ephemeral=ephemeral)
        else:
            await ctx_or_interaction.response.send_message(text, ephemeral=ephemeral)
    else:
        await ctx_or_interaction.reply(text, mention_author=False)

async def deploy_for(uid: int, ram=MEMBER_RAM, cpus=MEMBER_CPUS):
    mapping = load_mapping()
    existing = member_container(uid)
    if existing:
        return existing, None
    name = safe_name(uid)
    password = make_password()
    # Do not expose SSH on a public host port. SSH is reached via an explicit Pinggy tunnel.
    container = docker_client.containers.run(
        IMAGE, name=name, detach=True, init=True,
        mem_limit=ram, nano_cpus=int(float(cpus) * 1_000_000_000),
        pids_limit=256, cap_drop=["ALL"],
        cap_add=["CHOWN", "DAC_OVERRIDE", "FOWNER", "SETGID", "SETUID", "NET_BIND_SERVICE"],
        security_opt=["no-new-privileges:true"],
        restart_policy={"Name": "unless-stopped"},
        labels={"managed-by": "ophost-deploy-bot", "discord-user": str(uid)},
        environment={"DEPLOY_PASSWORD": password},
        network="bridge",
    )
    mapping[uid] = name
    save_mapping(mapping)
    return container, password

async def get_or_make(interaction, uid):
    c = member_container(uid)
    if c:
        return c
    mapping = load_mapping()
    if len([x for x in mapping if x == uid]) >= MAX_VPS_PER_MEMBER:
        return None
    c, password = await deploy_for(uid)
    # First-time credentials shown ephemerally only.
    await reply(interaction, f"VPS created: `{c.name}`\nSSH user: `deploy`\nTemporary password: `{password}`\n\nChange this password after connecting. Start a Pinggy tunnel from the host using the VPS SSH port instructions in README.", ephemeral=True)
    return c

@bot.event
async def on_ready():
    try:
        if GUILD_ID:
            guild = discord.Object(id=GUILD_ID)
            bot.tree.copy_global_to(guild=guild)
            synced = await bot.tree.sync(guild=guild)
        else:
            synced = await bot.tree.sync()
        print(f"Logged in as {bot.user}; synced {len(synced)} slash commands.")
    except Exception as e:
        print("Slash sync error:", e)

@bot.command(name="help")
async def help_cmd(ctx):
    await ctx.reply(
        "**OPHOST VPS Bot**\n"
        "`!claim` — create your VPS (if enabled)\n"
        "`!status` — your VPS status\n"
        "`!start` / `!stop` / `!restart` — manage your VPS\n"
        "`!ssh` — SSH/Pinggy setup info\n"
        "`!manage` — admin help (admins only)\n"
        "Admin slash commands: `/manage start`, `/manage stop`, `/manage reinstall`, `/manage sshx`, `/manage ssh`, `/manage termius`",
        mention_author=False
    )

@bot.command()
async def claim(ctx):
    if ctx.author.bot:
        return
    c = member_container(ctx.author.id)
    if c:
        await ctx.reply(f"Your VPS already exists: `{c.name}` (`{c.status}`).", mention_author=False)
        return
    if not docker_client.images.list(name=IMAGE):
        await ctx.reply("VPS image is not built yet. Admin: run `docker compose build` in the bot folder.", mention_author=False)
        return
    try:
        c, password = await deploy_for(ctx.author.id)
        await ctx.author.send(f"Your VPS `{c.name}` is ready.\nSSH user: `deploy`\nTemporary password: `{password}`\nChange it after connecting. Read README for Pinggy/Termius setup.")
        await ctx.reply("VPS created. I sent the initial login details by DM. Enable DMs from server members.", mention_author=False)
    except Exception as e:
        await ctx.reply(f"Deployment failed: `{type(e).__name__}`. Check bot logs.", mention_author=False)

@bot.command()
async def status(ctx):
    c = member_container(ctx.author.id)
    await ctx.reply(f"Your VPS: `{c.name}` — `{c.status}`" if c else "You do not have a VPS. Use `!claim`.", mention_author=False)

@bot.command()
async def start(ctx):
    c = member_container(ctx.author.id)
    if not c:
        return await ctx.reply("No VPS found. Use `!claim`.", mention_author=False)
    c.start()
    await ctx.reply(f"Started `{c.name}`.", mention_author=False)

@bot.command()
async def stop(ctx):
    c = member_container(ctx.author.id)
    if not c:
        return await ctx.reply("No VPS found.", mention_author=False)
    c.stop(timeout=10)
    await ctx.reply(f"Stopped `{c.name}`.", mention_author=False)

@bot.command()
async def restart(ctx):
    c = member_container(ctx.author.id)
    if not c:
        return await ctx.reply("No VPS found.", mention_author=False)
    c.restart(timeout=10)
    await ctx.reply(f"Restarted `{c.name}`.", mention_author=False)

@bot.command()
async def ssh(ctx):
    await ctx.reply("SSH is not exposed publicly by default. Ask an admin to create a Pinggy tunnel to your container's SSH port. See README; never share your password in a public channel.", mention_author=False)

@bot.command()
async def manage(ctx, action=None, member: discord.Member=None):
    if not is_admin_id(ctx.author.id):
        return await ctx.reply("Admin only.", mention_author=False)
    if not action:
        return await ctx.reply("Usage: `!manage start|stop|reinstall|sshx|ssh|termius [@member]`", mention_author=False)
    uid = member.id if member else ctx.author.id
    c = member_container(uid)
    action = action.lower()
    if action in ("ssh", "termius", "sshx"):
        return await ctx.reply("Use the `/manage ssh`, `/manage termius`, or `/manage sshx` slash command for connection instructions. Pinggy tunnel setup is documented in README.", mention_author=False)
    if not c:
        return await ctx.reply("VPS not found for that member.", mention_author=False)
    try:
        if action == "start":
            c.start()
        elif action == "stop":
            c.stop(timeout=10)
        elif action == "reinstall":
            c.remove(force=True)
            mapping = load_mapping()
            mapping.pop(uid, None)
            save_mapping(mapping)
            c, password = await deploy_for(uid)
            await ctx.author.send(f"Reinstalled `{c.name}`. New temporary password: `{password}`")
        else:
            return await ctx.reply("Unknown action. Use start, stop, reinstall, sshx, ssh, termius.", mention_author=False)
        await ctx.reply(f"`{action}` complete for `{c.name}`.", mention_author=False)
    except Exception as e:
        await ctx.reply(f"Action failed: `{type(e).__name__}`. Check logs.", mention_author=False)

manage_group = app_commands.Group(name="manage", description="Admin VPS management")
def admin_check(interaction: discord.Interaction):
    return is_admin_id(interaction.user.id)

async def slash_action(interaction, action: str, member: discord.Member | None):
    if not admin_check(interaction):
        return await reply(interaction, "Admin only.", ephemeral=True)
    uid = member.id if member else interaction.user.id
    c = member_container(uid)
    if action in ("ssh", "termius", "sshx"):
        texts = {
            "ssh": "SSH access uses a Pinggy tunnel. Do not publish credentials. Follow the README tunnel instructions on the VPS host.",
            "termius": "In Termius, add a host using the Pinggy-provided host and port; username is `deploy`. Use the temporary password privately, then change it.",
            "sshx": "SSHX is an optional third-party service. Install/use it only if you trust the service and understand that it can expose terminal access. This bot does not silently install it."
        }
        return await reply(interaction, texts[action], ephemeral=True)
    if not c:
        return await reply(interaction, "VPS not found. Member must use `!claim` first.", ephemeral=True)
    try:
        await interaction.response.defer(ephemeral=True)
        if action == "start":
            c.start()
        elif action == "stop":
            c.stop(timeout=10)
        elif action == "reinstall":
            c.remove(force=True)
            mapping = load_mapping()
            mapping.pop(uid, None)
            save_mapping(mapping)
            newc, password = await deploy_for(uid)
            await interaction.followup.send(f"Reinstalled `{newc.name}`. New temporary password: `{password}`", ephemeral=True)
            return
        await interaction.followup.send(f"{action} complete for `{c.name}`.", ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"Action failed: `{type(e).__name__}`. Check bot logs.", ephemeral=True)

@manage_group.command(name="start", description="Start a member VPS")
@app_commands.describe(member="Member whose VPS to start")
async def slash_start(interaction: discord.Interaction, member: discord.Member | None = None):
    await slash_action(interaction, "start", member)

@manage_group.command(name="stop", description="Stop a member VPS")
@app_commands.describe(member="Member whose VPS to stop")
async def slash_stop(interaction: discord.Interaction, member: discord.Member | None = None):
    await slash_action(interaction, "stop", member)

@manage_group.command(name="reinstall", description="Reinstall a member VPS (data is deleted)")
@app_commands.describe(member="Member whose VPS to reinstall")
async def slash_reinstall(interaction: discord.Interaction, member: discord.Member | None = None):
    await slash_action(interaction, "reinstall", member)

@manage_group.command(name="sshx", description="Show SSHX safety/setup information")
async def slash_sshx(interaction: discord.Interaction, member: discord.Member | None = None):
    await slash_action(interaction, "sshx", member)

@manage_group.command(name="ssh", description="Show SSH/Pinggy setup instructions")
async def slash_ssh(interaction: discord.Interaction, member: discord.Member | None = None):
    await slash_action(interaction, "ssh", member)

@manage_group.command(name="termius", description="Show Termius connection instructions")
async def slash_termius(interaction: discord.Interaction, member: discord.Member | None = None):
    await slash_action(interaction, "termius", member)

bot.tree.add_command(manage_group)

if __name__ == "__main__":
    if not TOKEN or not ADMIN_IDS:
        raise SystemExit("Set BOT_TOKEN and ADMIN_IDS in .env first.")
    bot.run(TOKEN)
