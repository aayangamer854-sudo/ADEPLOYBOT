# OPHOST Docker VPS Deploy Bot

Discord bot with `!` member commands, admin-only `!manage` and `/manage` actions, and Docker-managed Ubuntu SSH containers.

## Requirements
- A Linux VPS you own/administer, with Docker Engine and Python 3.10+
- Discord bot token; enable **Message Content Intent** in the Discord Developer Portal for `!` commands
- Admin Discord user ID. For quickest slash-command registration, optionally set `GUILD_ID` to your test server ID.

## Install
```bash
chmod +x install.sh
./install.sh
```
The installer asks for the bot token, admin ID, server ID, RAM and CPU defaults, then builds the VPS image and installs dependencies. It creates a private `.env` file. Never upload `.env` or share the bot token.

Start directly:
```bash
source .venv/bin/activate
python bot.py
```
Or run the bot in Docker:
```bash
docker compose up -d --build
docker compose logs -f bot
```

## Commands
Members:
- `!claim` create a VPS (initial password is sent by DM)
- `!status`, `!start`, `!stop`, `!restart`
- `!ssh`, `!help`

Admins:
- `!manage start @member`
- `!manage stop @member`
- `!manage reinstall @member` — **deletes the old container and its writable data**
- `/manage start`, `/manage stop`, `/manage reinstall`
- `/manage ssh`, `/manage sshx`, `/manage termius`

## Pinggy and Termius
The image runs SSH on port 22 **inside** each container, but does not publish it to the public internet. A secure per-container SSH tunnel needs a unique host-side forwarded port or an individually managed Pinggy tunnel. Do not blindly expose all containers' port 22. This starter bot deliberately displays setup guidance rather than automatically launching a tunnel with a third-party service account.

For a single container, an admin can temporarily publish its SSH port to loopback only by recreating it with a host port mapping such as `127.0.0.1:2201:22`, then create a Pinggy TCP/SSH tunnel from the host to that loopback port according to Pinggy's current documentation. Pinggy's host/port output is what you enter in Termius:
- Host: the host provided by Pinggy
- Port: the port provided by Pinggy
- Username: `deploy`
- Password: the temporary password DM'd on first creation

Do not post credentials in Discord channels. Change the password after connecting. For production, prefer SSH keys and per-user isolated networks/quotas.

## Important security notes
- **Docker socket access is effectively root access to the host.** Only install on your own VPS and restrict who can administer the bot.
- Containers are resource-limited by RAM, CPU and PID count. `MEMBER_DISK_NOTE` is informational only: Docker does not enforce a disk quota here. Configure filesystem/project quotas separately before advertising disk limits.
- `reinstall` removes the container and its writable data. Back up anything important first.
- SSHX is not installed automatically; `/manage sshx` gives a safety note. Review third-party services before granting terminal access.
- This is a starter implementation, not a hardened multi-tenant hosting platform. Add billing, abuse controls, audit logs, quota enforcement, key-based SSH and proper per-container tunnel orchestration before public use.
