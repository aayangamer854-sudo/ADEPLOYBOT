#!/bin/bash
set -e
if [ -z "${DEPLOY_PASSWORD:-}" ]; then
  echo "DEPLOY_PASSWORD is required" >&2
  exit 1
fi
echo "deploy:${DEPLOY_PASSWORD}" | chpasswd
exec /usr/sbin/sshd -D -e
