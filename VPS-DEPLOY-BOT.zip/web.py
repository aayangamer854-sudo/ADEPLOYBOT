from fastapi import FastAPI, HTTPException
from core.db import init_db, list_vps, get_vps
from core.incus import action
app=FastAPI(title="VPS Deploy API")
init_db()

@app.get("/health")
def health(): return {"ok":True}

@app.get("/vps")
def vps(): return [dict(x) for x in list_vps()]

@app.get("/vps/{name}")
def one(name:str):
    x=get_vps(name)
    if not x: raise HTTPException(404,"VPS not found")
    return dict(x)

@app.post("/vps/{name}/{verb}")
def ctl(name:str,verb:str):
    if verb not in ("start","stop","restart","delete"): raise HTTPException(400,"Invalid action")
    if not get_vps(name): raise HTTPException(404,"VPS not found")
    action(name,verb); return {"ok":True}
