#!/usr/bin/env bash
set -e
if [ "$(id -u)" -ne 0 ]; then echo "Run as root: sudo bash install.sh"; exit 1; fi
apt-get update
apt-get install -y python3 python3-venv python3-pip sqlite3 curl ca-certificates
# Install Incus from the distro if available. Ubuntu/Debian versions vary.
if ! command -v incus >/dev/null 2>&1; then
  apt-get install -y incus || true
fi
if ! command -v incus >/dev/null 2>&1; then
  echo "Incus was not available from your distro repositories."
  echo "Install Incus using the official Incus documentation, then rerun this script."
  exit 1
fi
mkdir -p data
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp -n .env.example .env
python -c "from core.db import init_db; init_db()"
chmod +x start.sh start-api.sh
echo
echo "Installed. Edit .env and put your Discord bot token there."
echo "Start bot: ./start.sh"
echo "Start API: ./start-api.sh"
