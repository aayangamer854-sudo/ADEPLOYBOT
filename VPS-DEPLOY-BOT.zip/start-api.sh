#!/usr/bin/env bash
set -e
source .venv/bin/activate
uvicorn web:app --host "${API_HOST:-127.0.0.1}" --port "${API_PORT:-8080}"
