# VPS Deploy Bot

A Discord-based VPS provisioning starter built independently with Python, Discord slash commands, FastAPI, SQLite and Incus/LXC.

## Features
- `/deploy` with OS image, RAM, CPU and disk limits
- `/vps`, `/vps-info`
- `/start`, `/stop`, `/restart`, `/delete`
- Admin `/admin-list`
- SQLite database
- FastAPI API
- Native Incus/LXC runtime; Docker is not required
- Resource limits at the container level
- Simple installer and launcher scripts

## Requirements
- KVM VPS or bare-metal Linux host
- Root/sudo access
- Incus installed and initialized
- A Discord application/bot token

## Install
```bash
git clone YOUR_REPO_URL VPS-DEPLOY-BOT
cd VPS-DEPLOY-BOT
sudo bash install.sh
nano .env
./start.sh
```

For Incus, initialize storage/network once according to your distribution's Incus setup.

## Discord bot
In the Discord Developer Portal, create an application and bot, then invite it with the `bot` and `applications.commands` scopes and suitable permissions.

Put the token in `.env`:
```env
DISCORD_TOKEN=your_token
ADMIN_ROLE=Admin
```

Never publish `.env` or your bot token.

## Production notes
This starter intentionally keeps authentication, billing, quotas, backups, image catalogs, audit logs, web authentication, password/cloud-init handling and multi-node orchestration separate. Before offering VPSs to other people, add those controls and put the API behind HTTPS plus authentication.

## Important
The bot runs provisioning commands with the permissions of the Linux account running it. Use a dedicated host/service account and least-privilege design for a production deployment.
