import sqlite3, os
DB=os.getenv("DB_PATH","data/vps.db")
os.makedirs(os.path.dirname(DB),exist_ok=True)

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init_db():
    with conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS vps(
        name TEXT PRIMARY KEY, owner_id TEXT NOT NULL, image TEXT, ram INTEGER,
        cpu INTEGER, disk INTEGER, ip TEXT, status TEXT DEFAULT 'unknown',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
def create_vps(name,owner,image,ram,cpu,disk,ip):
    with conn() as c: c.execute("INSERT INTO vps(name,owner_id,image,ram,cpu,disk,ip,status) VALUES(?,?,?,?,?,?,?,?)",(name,owner,image,ram,cpu,disk,ip,"running"))
def get_vps(name,owner=None):
    with conn() as c:
        return c.execute("SELECT * FROM vps WHERE name=?"+(" AND owner_id=?" if owner else ""), (name,owner) if owner else (name,)).fetchone()
def list_vps(owner=None):
    with conn() as c:
        return c.execute("SELECT * FROM vps"+(" WHERE owner_id=?" if owner else ""), (owner,) if owner else ()).fetchall()
def delete_vps(name,owner=None):
    with conn() as c: c.execute("DELETE FROM vps WHERE name=?"+(" AND owner_id=?" if owner else ""), (name,owner) if owner else (name,))
