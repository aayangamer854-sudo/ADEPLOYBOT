import subprocess, ipaddress

def run(*args):
    p=subprocess.run(["incus",*args],text=True,capture_output=True)
    if p.returncode: raise RuntimeError(p.stderr.strip() or "Incus command failed")
    return p.stdout.strip()

def deploy(name,image,ram,cpu,disk):
    if not name.replace("-","").replace("_","").isalnum(): raise ValueError("Invalid VPS name")
    run("launch",image,name)
    run("config","set",name,"limits.memory",f"{ram}MiB")
    run("config","set",name,"limits.cpu",str(cpu))
    run("config","device","override",name,"root","size",f"{disk}GiB")
    run("start",name)
    out=run("list",name,"-c","4","--format","csv")
    ip=""
    try:
        # Incus list -c 4 is IPv4 addresses; pick the first non-link-local address.
        for part in out.split(","):
            part=part.strip()
            try:
                x=ipaddress.ip_address(part)
                if x.version==4 and not x.is_loopback: ip=str(x); break
            except: pass
    except: pass
    return {"ip":ip}

def action(name,verb):
    if verb=="delete": return run("delete",name,"--force")
    return run(verb,name)

def info(name):
    return {"status":run("list",name,"-c","s","--format","csv")}
