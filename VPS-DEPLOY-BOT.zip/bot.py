import os
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from core.db import init_db, create_vps, list_vps, get_vps, delete_vps
from core.incus import deploy, action, info

load_dotenv()
TOKEN=os.getenv("DISCORD_TOKEN")
ADMIN_ROLE=os.getenv("ADMIN_ROLE","Admin")

intents=discord.Intents.default()
bot=commands.Bot(command_prefix="!", intents=intents)

def is_admin(interaction):
    return interaction.user.guild_permissions.administrator or any(r.name==ADMIN_ROLE for r in getattr(interaction.user,"roles",[]))

@bot.event
async def on_ready():
    init_db()
    await bot.tree.sync()
    print(f"Logged in as {bot.user}.")

@bot.tree.command(name="deploy", description="Deploy a VPS container")
@app_commands.describe(name="VPS name", image="OS image", ram="RAM in MB", cpu="CPU cores", disk="Disk in GB")
async def deploy_cmd(interaction: discord.Interaction, name:str, image:str="images:ubuntu/24.04", ram:int=2048, cpu:int=2, disk:int=20):
    await interaction.response.defer(ephemeral=True)
    if not 512 <= ram <= 32768 or not 1 <= cpu <= 16 or not 5 <= disk <= 500:
        return await interaction.followup.send("Invalid resource limits.")
    try:
        result=deploy(name,image,ram,cpu,disk)
        create_vps(name, str(interaction.user.id), image, ram, cpu, disk, result["ip"])
        await interaction.followup.send(
            f"✅ VPS deployed\n**Name:** `{name}`\n**IP:** `{result['ip']}`\n"
            f"**RAM:** {ram} MB\n**CPU:** {cpu}\n**Disk:** {disk} GB\n"
            f"**SSH:** `ssh root@{result['ip']}`\n"
            f"**Note:** Set a root password with `/console` or your image's cloud-init before exposing SSH."
        )
    except Exception as e:
        await interaction.followup.send(f"❌ Deploy failed: `{e}`")

@bot.tree.command(name="vps", description="Show your VPS")
async def vps_cmd(interaction: discord.Interaction):
    rows=list_vps(str(interaction.user.id))
    if not rows:
        return await interaction.response.send_message("No VPS found.", ephemeral=True)
    text="\n".join(f"`{r['name']}` — {r['status']} — {r['ip'] or 'no-ip'}" for r in rows)
    await interaction.response.send_message(text, ephemeral=True)

@bot.tree.command(name="vps-info", description="Show VPS details")
@app_commands.describe(name="VPS name")
async def vps_info(interaction: discord.Interaction, name:str):
    row=get_vps(name, str(interaction.user.id))
    if not row:
        return await interaction.response.send_message("VPS not found.", ephemeral=True)
    try:
        data=info(name)
        await interaction.response.send_message(
            f"**{name}**\nStatus: `{data.get('status','unknown')}`\nIP: `{row['ip'] or 'unknown'}`\n"
            f"RAM: `{row['ram']} MB` CPU: `{row['cpu']}` Disk: `{row['disk']} GB`", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Info error: `{e}`", ephemeral=True)

async def do_action(interaction, name, verb):
    row=get_vps(name, str(interaction.user.id))
    if not row:
        return await interaction.response.send_message("VPS not found.", ephemeral=True)
    await interaction.response.defer(ephemeral=True)
    try:
        action(name, verb)
        await interaction.followup.send(f"✅ `{verb}` completed for `{name}`")
    except Exception as e:
        await interaction.followup.send(f"❌ `{e}`")

@bot.tree.command(name="start", description="Start your VPS")
async def start(interaction:discord.Interaction,name:str): await do_action(interaction,name,"start")
@bot.tree.command(name="stop", description="Stop your VPS")
async def stop(interaction:discord.Interaction,name:str): await do_action(interaction,name,"stop")
@bot.tree.command(name="restart", description="Restart your VPS")
async def restart(interaction:discord.Interaction,name:str): await do_action(interaction,name,"restart")

@bot.tree.command(name="delete", description="Delete your VPS")
async def delete(interaction:discord.Interaction,name:str):
    row=get_vps(name,str(interaction.user.id))
    if not row: return await interaction.response.send_message("VPS not found.",ephemeral=True)
    await interaction.response.defer(ephemeral=True)
    try:
        action(name,"delete"); delete_vps(name,str(interaction.user.id))
        await interaction.followup.send(f"🗑️ Deleted `{name}`")
    except Exception as e: await interaction.followup.send(f"❌ `{e}`")

@bot.tree.command(name="admin-list", description="List all VPS (admin)")
async def admin_list(interaction:discord.Interaction):
    if not is_admin(interaction): return await interaction.response.send_message("Admin only.",ephemeral=True)
    rows=list_vps()
    text="\n".join(f"`{r['name']}` | owner `{r['owner_id']}` | {r['status']} | {r['ip']}" for r in rows) or "No VPS."
    await interaction.response.send_message(text[:1900],ephemeral=True)

bot.run(TOKEN)
